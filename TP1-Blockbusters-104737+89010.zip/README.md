#VI PROJECT

##blockbusters

In order to run the app, start a local server from the folder with index.html

Example:

1-open terminal and go to app folder

2-enter the following command: "python -m http.server 8888"

3-open up a browser and enter the following url: "http://localhost:8888/index.html"

The visualizations aimed at investors are in investors.html, data exploration features are in data.html
